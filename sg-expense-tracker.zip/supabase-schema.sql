-- ============================================
-- SG EXPENSE TRACKER - SUPABASE SCHEMA
-- ============================================
-- Run this SQL in your Supabase SQL Editor to set up the database
-- 
-- Steps:
-- 1. Go to your Supabase project dashboard
-- 2. Click "SQL Editor" in the sidebar
-- 3. Click "New query"
-- 4. Paste this entire file
-- 5. Click "Run"
-- ============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- TRANSACTIONS TABLE
-- ============================================
-- This is the main table storing all expenses and income

CREATE TABLE IF NOT EXISTS transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  
  -- Financial data
  amount DECIMAL(10, 2) NOT NULL,
  -- Negative = expense, Positive = income
  
  -- Description
  description TEXT,
  
  -- Category reference (matches app categories)
  -- Expenses: 1-12, Income: 100-104
  category_id INTEGER NOT NULL,
  
  -- Transaction date (not necessarily when it was recorded)
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  
  -- Metadata
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- For future multi-user support
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================

-- Index for date-based queries (monthly summaries, etc.)
CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(date DESC);

-- Index for category filtering
CREATE INDEX IF NOT EXISTS idx_transactions_category ON transactions(category_id);

-- Composite index for user + date queries
CREATE INDEX IF NOT EXISTS idx_transactions_user_date ON transactions(user_id, date DESC);

-- ============================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================
-- This ensures users can only see their own data

ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- Policy: Users can only see their own transactions
CREATE POLICY "Users can view own transactions" ON transactions
  FOR SELECT
  USING (auth.uid() = user_id OR user_id IS NULL);

-- Policy: Users can insert their own transactions
CREATE POLICY "Users can insert own transactions" ON transactions
  FOR INSERT
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- Policy: Users can update their own transactions
CREATE POLICY "Users can update own transactions" ON transactions
  FOR UPDATE
  USING (auth.uid() = user_id OR user_id IS NULL);

-- Policy: Users can delete their own transactions
CREATE POLICY "Users can delete own transactions" ON transactions
  FOR DELETE
  USING (auth.uid() = user_id OR user_id IS NULL);

-- ============================================
-- ALLOW ANONYMOUS ACCESS (for simple setup)
-- ============================================
-- If you want to use without authentication, run this:
-- (Remove this section if you want user-based authentication)

CREATE POLICY "Allow anonymous access" ON transactions
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- ============================================
-- BUDGETS TABLE (Optional)
-- ============================================
-- Store monthly budgets per category

CREATE TABLE IF NOT EXISTS budgets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  category_id INTEGER NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  month DATE NOT NULL, -- First day of the month
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(category_id, month, user_id)
);

ALTER TABLE budgets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow anonymous budget access" ON budgets
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- ============================================
-- GOALS TABLE (Optional)
-- ============================================
-- Store savings goals

CREATE TABLE IF NOT EXISTS goals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  target_amount DECIMAL(10, 2) NOT NULL,
  current_amount DECIMAL(10, 2) DEFAULT 0,
  icon TEXT,
  color TEXT,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE goals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow anonymous goals access" ON goals
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- ============================================
-- USEFUL VIEWS
-- ============================================

-- Monthly summary view
CREATE OR REPLACE VIEW monthly_summary AS
SELECT 
  DATE_TRUNC('month', date) as month,
  SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END) as total_income,
  SUM(CASE WHEN amount < 0 THEN ABS(amount) ELSE 0 END) as total_expenses,
  SUM(amount) as net,
  COUNT(*) as transaction_count
FROM transactions
GROUP BY DATE_TRUNC('month', date)
ORDER BY month DESC;

-- Category spending summary
CREATE OR REPLACE VIEW category_spending AS
SELECT 
  category_id,
  DATE_TRUNC('month', date) as month,
  SUM(ABS(amount)) as total_spent,
  COUNT(*) as transaction_count
FROM transactions
WHERE amount < 0
GROUP BY category_id, DATE_TRUNC('month', date)
ORDER BY month DESC, total_spent DESC;

-- ============================================
-- SAMPLE DATA (Singapore Context)
-- ============================================
-- Uncomment and run this to add sample transactions

/*
INSERT INTO transactions (amount, description, category_id, date) VALUES
  (-5.00, 'Chicken rice at Maxwell', 1, CURRENT_DATE),
  (-2.10, 'MRT to Raffles Place', 2, CURRENT_DATE),
  (-1.50, 'Kopi-O at kopitiam', 6, CURRENT_DATE),
  (-15.80, 'Grab to Changi', 9, CURRENT_DATE),
  (-89.00, 'SP Services electricity', 5, CURRENT_DATE - INTERVAL '1 day'),
  (-45.60, 'NTUC FairPrice groceries', 3, CURRENT_DATE - INTERVAL '2 days'),
  (-12.90, 'Netflix subscription', 11, CURRENT_DATE - INTERVAL '3 days'),
  (-8.50, 'Ya Kun Kaya Toast set', 6, CURRENT_DATE - INTERVAL '3 days'),
  (8500.00, 'Salary', 100, DATE_TRUNC('month', CURRENT_DATE)),
  (-156.00, 'Singtel mobile bill', 5, CURRENT_DATE - INTERVAL '5 days'),
  (-4.50, 'Laksa at Old Airport Road', 1, CURRENT_DATE - INTERVAL '1 day'),
  (-22.00, 'Golden Village movie', 7, CURRENT_DATE - INTERVAL '4 days'),
  (-3.80, 'Bus 14 + MRT', 2, CURRENT_DATE - INTERVAL '2 days'),
  (-199.00, 'Uniqlo clothes', 4, CURRENT_DATE - INTERVAL '6 days');
*/

-- ============================================
-- FUNCTIONS
-- ============================================

-- Function to get spending by category for a given month
CREATE OR REPLACE FUNCTION get_monthly_category_spending(
  target_month DATE DEFAULT DATE_TRUNC('month', CURRENT_DATE)
)
RETURNS TABLE (
  category_id INTEGER,
  total_spent DECIMAL,
  transaction_count BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    t.category_id,
    SUM(ABS(t.amount)) as total_spent,
    COUNT(*) as transaction_count
  FROM transactions t
  WHERE t.amount < 0
    AND DATE_TRUNC('month', t.date) = DATE_TRUNC('month', target_month)
  GROUP BY t.category_id
  ORDER BY total_spent DESC;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- DONE!
-- ============================================
-- Your database is now ready to use.
-- 
-- In your Supabase dashboard:
-- 1. Go to Settings > API
-- 2. Copy the "URL" and "anon public" key
-- 3. Paste them into the SG Expense Tracker app
-- ============================================
